import Component from "@glimmer/component";
import { get } from "@ember/object";
import { service } from "@ember/service";
import { apiInitializer } from "discourse/lib/api";
import dIcon from "discourse/ui-kit/helpers/d-icon";
import { i18n } from "discourse-i18n";

class ComposerAudience extends Component {
  @service siteSettings;

  get restricted() {
    const model = this.args.outletArgs?.composer;
    return model ? get(model, "category.read_restricted") : undefined;
  }

  get visible() {
    return this.siteSettings.enable_composer_redesign &&
      typeof this.restricted === "boolean";
  }

  get label() {
    return i18n(this.restricted
      ? "category.visibility.group_restricted"
      : "category.visibility.public");
  }

  <template>
    {{#if this.visible}}
      <div
        class="fomio-composer-audience"
        title={{i18n "category.visibility.who_can_see"}}
      >
        {{dIcon (if this.restricted "lock" "globe")}}
        <span>{{this.label}}</span>
      </div>
    {{/if}}
  </template>
}

export default apiInitializer((api) => {
  // Native category/serializer data, no permission inference or new request.
  // The outlet only exists when core permits the category chooser.
  api.renderInOutlet("after-composer-category-input", ComposerAudience);
});
