import { apiInitializer } from "discourse/lib/api";
import { groupComposerFormatting } from "../lib/fomio-composer-format";
import { i18n } from "discourse-i18n";

export default apiInitializer((api) => {
  // Native commands and menu lifecycle, verified in the local Discourse.
  // No preference, site setting, editor content or submit action is changed.
  api.onToolbarCreate((toolbar) => {
    groupComposerFormatting(toolbar, {
      title: themePrefix("composer.format"),
      label: i18n(themePrefix("composer.format")),
    });
  });
});
